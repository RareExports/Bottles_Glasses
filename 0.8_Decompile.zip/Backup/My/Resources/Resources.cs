﻿// Decompiled with JetBrains decompiler
// Type: BK_Viewer.My.Resources.Resources
// Assembly: BK_Viewer, Version=0.0.8.0, Culture=neutral, PublicKeyToken=null
// MVID: ADE61EBF-8BD6-4B49-8807-0356A6D4EFA6
// Assembly location: C:\Users\zelda\OneDrive\Desktop\BottlesGlasses_0.8\BK_Viewer.exe

using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace BK_Viewer.My.Resources
{
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "2.0.0.0")]
  [DebuggerNonUserCode]
  [StandardModule]
  [HideModuleName]
  [CompilerGenerated]
  internal sealed class Resources
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (object.ReferenceEquals((object) BK_Viewer.My.Resources.Resources.resourceMan, (object) null))
          BK_Viewer.My.Resources.Resources.resourceMan = new ResourceManager("BK_Viewer.Resources", typeof (BK_Viewer.My.Resources.Resources).Assembly);
        return BK_Viewer.My.Resources.Resources.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get
      {
        return BK_Viewer.My.Resources.Resources.resourceCulture;
      }
      set
      {
        BK_Viewer.My.Resources.Resources.resourceCulture = value;
      }
    }

    internal static Bitmap axisoff
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(BK_Viewer.My.Resources.Resources.ResourceManager.GetObject("axisoff", BK_Viewer.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap axison
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(BK_Viewer.My.Resources.Resources.ResourceManager.GetObject("axison", BK_Viewer.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap axison1
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(BK_Viewer.My.Resources.Resources.ResourceManager.GetObject("axison1", BK_Viewer.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap Clipboard01
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(BK_Viewer.My.Resources.Resources.ResourceManager.GetObject("Clipboard01", BK_Viewer.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap easteregg
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(BK_Viewer.My.Resources.Resources.ResourceManager.GetObject("easteregg", BK_Viewer.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap grun_s2
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(BK_Viewer.My.Resources.Resources.ResourceManager.GetObject("grun_s2", BK_Viewer.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap mumbo
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(BK_Viewer.My.Resources.Resources.ResourceManager.GetObject("mumbo", BK_Viewer.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap off
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(BK_Viewer.My.Resources.Resources.ResourceManager.GetObject("off", BK_Viewer.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap ph10
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(BK_Viewer.My.Resources.Resources.ResourceManager.GetObject("ph10", BK_Viewer.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap pluma_roja
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(BK_Viewer.My.Resources.Resources.ResourceManager.GetObject("pluma_roja", BK_Viewer.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap textures_off
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(BK_Viewer.My.Resources.Resources.ResourceManager.GetObject("textures_off", BK_Viewer.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap textures_on
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(BK_Viewer.My.Resources.Resources.ResourceManager.GetObject("textures_on", BK_Viewer.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap texturesoff
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(BK_Viewer.My.Resources.Resources.ResourceManager.GetObject("texturesoff", BK_Viewer.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap textureson
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(BK_Viewer.My.Resources.Resources.ResourceManager.GetObject("textureson", BK_Viewer.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap vrml
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(BK_Viewer.My.Resources.Resources.ResourceManager.GetObject("vrml", BK_Viewer.My.Resources.Resources.resourceCulture));
      }
    }

    internal static string VRMLHeader
    {
      get
      {
        return BK_Viewer.My.Resources.Resources.ResourceManager.GetString("VRMLHeader", BK_Viewer.My.Resources.Resources.resourceCulture);
      }
    }

    internal static Bitmap wireframeoff1
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(BK_Viewer.My.Resources.Resources.ResourceManager.GetObject("wireframeoff1", BK_Viewer.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap wireframeon1
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(BK_Viewer.My.Resources.Resources.ResourceManager.GetObject("wireframeon1", BK_Viewer.My.Resources.Resources.resourceCulture));
      }
    }
  }
}
