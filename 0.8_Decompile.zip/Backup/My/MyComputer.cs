﻿// Decompiled with JetBrains decompiler
// Type: BK_Viewer.My.MyComputer
// Assembly: BK_Viewer, Version=0.0.8.0, Culture=neutral, PublicKeyToken=null
// MVID: ADE61EBF-8BD6-4B49-8807-0356A6D4EFA6
// Assembly location: C:\Users\zelda\OneDrive\Desktop\BottlesGlasses_0.8\BK_Viewer.exe

using Microsoft.VisualBasic.Devices;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;

namespace BK_Viewer.My
{
  [GeneratedCode("MyTemplate", "8.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  internal class MyComputer : Computer
  {
    [EditorBrowsable(EditorBrowsableState.Never)]
    [DebuggerHidden]
    public MyComputer()
    {
    }
  }
}
