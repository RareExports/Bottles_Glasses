﻿// Decompiled with JetBrains decompiler
// Type: BK_Viewer.F3DEX
// Assembly: BK_Viewer, Version=0.0.8.0, Culture=neutral, PublicKeyToken=null
// MVID: ADE61EBF-8BD6-4B49-8807-0356A6D4EFA6
// Assembly location: C:\Users\zelda\OneDrive\Desktop\BottlesGlasses_0.8\BK_Viewer.exe

using Microsoft.VisualBasic.CompilerServices;

namespace BK_Viewer
{
  [StandardModule]
  internal sealed class F3DEX
  {
    public static byte G_CULL_FRONT = 2;
    public static byte G_CULL_BACK = 4;
    public static byte G_CULL_BOTH = 6;
    public static byte G_FOG = 0;
    public static byte G_LIGHTING = 0;
    public static byte G_TEXTURE_GEN = 0;
    public static byte G_TEXTURE_GEN_LINEAR = 0;
    public static byte G_LOD = 0;
    public static byte G_SHADING_SMOOTH = 0;
    public static byte G_CLIPPING = 0;
    public static byte F3DEX_DL = 0;
    public static byte F3DEX_POPMTX = 0;
    public static byte F3DEX_TEXTURE = 0;
    public static byte F3DEX_SETOTHERMODE_H = 0;
    public static byte F3DEX_SETOTHERMODE_L = 0;
    public static byte F3DEX_MTX = 0;
    public static byte F3DEX_SETGEOMETRYMODE = 0;
    public static byte F3DEX_CLEARGEOMETRYMODE = 0;
    public static byte F3DEX_ENDDL = 0;
    public static byte F3DEX_VTX = 0;
    public static byte F3DEX_MODIFYVTX = 0;
    public static byte F3DEX_BRANCH_Z = 0;
    public static byte F3DEX_TRI1 = 0;
    public static byte F3DEX_TRI2 = 0;
    public const byte G_SETCIMG = 255;
    public const byte G_SETZIMG = 254;
    public const byte G_SETTIMG = 253;
    public const byte G_SETCOMBINE = 252;
    public const byte G_SETENVCOLOR = 251;
    public const byte G_SETBLENDCOLOR = 249;
    public const byte G_SETFOGCOLOR = 248;
    public const byte G_SETPRIMCOLOR = 250;
    public const byte G_SETFILLCOLOR = 247;
    public const byte G_FILLRECT = 246;
    public const byte G_SETTILE = 245;
    public const byte G_LOADTILE = 244;
    public const byte G_LOADBLOCK = 243;
    public const byte G_SETTILESIZE = 242;
    public const byte G_LOADTLUT = 240;
    public const byte G_RDPSETOTHERMODE = 239;
    public const byte G_SETPRIMDEPTH = 238;
    public const byte G_SETSCISSOR = 237;
    public const byte G_SETCONVERT = 236;
    public const byte G_SETKEYR = 235;
    public const byte G_SETKEYGB = 234;
    public const byte G_RDPFULLSYNC = 233;
    public const byte G_RDPTILESYNC = 232;
    public const byte G_RDPPIPESYNC = 231;
    public const byte G_RDPLOADSYNC = 230;
    public const byte G_TEXRECTFLIP = 229;
    public const byte G_TEXRECT = 228;
  }
}
