﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyProduct("Bottles' Glasses")]
[assembly: AssemblyCopyright("Copyright © cooliscool 2007- 2009")]
[assembly: AssemblyCompany("cooliscool")]
[assembly: Guid("92b38140-bb54-407b-b0ea-0801bb383678")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyFileVersion("0.0.8.0")]
[assembly: AssemblyDescription("Banjo Kazooie/Banjo Tooie model viewer/ripper")]
[assembly: ComVisible(false)]
[assembly: AssemblyTitle("Bottles' Glasses")]
[assembly: AssemblyVersion("0.0.8.0")]
